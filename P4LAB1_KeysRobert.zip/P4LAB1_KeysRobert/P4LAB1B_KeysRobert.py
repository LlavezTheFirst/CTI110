#Robert Keys
#11/01/2024
#P4LAB1B
#Initials using turtle

import turtle

# Create and setup the turtle
win = turtle.Screen()     # Creates a playground for turtles
t = turtle.Turtle()       # Create a turtle, assign to t
t.pensize(3)             # increase pensize (takes integer)
t.pencolor("red")      # set pencolor (takes string)
t.shape("turtle")

# Draw first initial 'R'
t.pendown()
t.right(90)
t.forward(100)        # vertical line of R
t.backward(100)       # go back to top
t.left(90)
t.forward(50)         # top of R
t.right(90)
t.forward(50)         # to middle of R
t.right(90)
t.forward(50)         # back to vertical
t.left(135)
t.forward(70)         # diagonal line of R

# Move to position for second initial
t.penup()
t.goto(120, 0)        # move right to start K
t.setheading(90)      # point turtle up
t.pendown()

# Draw second initial 'K'
t.forward(100)        # vertical line of K
t.backward(50)        # back to middle
t.right(45)
t.forward(70)         # upper diagonal of K
t.backward(70)        # back to middle
t.right(90)
t.forward(70)         # lower diagonal of K

# Keep window open
turtle.done()
