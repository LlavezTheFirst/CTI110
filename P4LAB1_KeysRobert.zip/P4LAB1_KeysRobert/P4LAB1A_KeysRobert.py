#Robert Keys
#11/01/2024
#P4LAB1A
#Initials using turtle

import turtle             # Allows us to use turtles
win = turtle.Screen()     # Creates a playground for turtles
t = turtle.Turtle()       # Create a turtle, assign to t
t.pensize(3)             # increase pensize (takes integer)
t.pencolor("purple")      # set pencolor (takes string)
t.shape("turtle")

# Pseudocode:
# 1. Setup first shape (square)
# 2. Use while loop to draw square
# 3. Move turtle to new position
# 4. Use while loop to draw triangle

# Draw square
sides_drawn = 0          # Counter for sides drawn
while sides_drawn < 4:   # Draw 4 sides for square
    t.forward(50)        # Move forward 50 units
    t.left(90)          # Turn 90 degrees left
    sides_drawn += 1     # Increment counter

# Move to position for second shape
t.penup()
t.goto(145, 0)          # move right
t.setheading(90)        # point turtle up
t.pendown()

# Draw triangle
sides_drawn = 0         # Reset counter for triangle
while sides_drawn < 3:  # Draw 3 sides for triangle
    t.forward(100)      # Move forward 100 units    
    t.left(120)        # Turn 120 degrees left
    sides_drawn += 1   # Increment counter

win.mainloop()         # Wait for user to close window
